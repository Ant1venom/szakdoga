class Structure:
    def __init__(self):
        self.feed_streams = []
        self.product_streams = []
        self.dividers = []
        self.separators = []
        self.mixers = []
        self.connections = []
        self.layers = 0
        self.max_dividers_in_single_layer = 0


